import os
import json
import csv
import pickle
import zipfile

class flo:
    @staticmethod
    def connect(file_path):
        ext = os.path.splitext(file_path)[1]
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File '{file_path}' not found.")

        with open(file_path, 'rb' if ext == '.pkl' else 'r', encoding='utf-8') as f:
            if ext == '.json':
                return json.load(f)
            elif ext == '.csv':
                return list(csv.reader(f))
            elif ext == '.txt':
                return f.read()
            elif ext == '.pkl':
                return pickle.load(f)
            else:
                raise ValueError("Unsupported file type")

    @staticmethod
    def write(file_path, data):
        ext = os.path.splitext(file_path)[1]

        with open(file_path, 'wb' if ext == '.pkl' else 'w', encoding='utf-8') as f:
            if ext == '.json':
                json.dump(data, f, indent=4)
            elif ext == '.csv':
                writer = csv.writer(f)
                writer.writerows(data if isinstance(data, list) else [data])
            elif ext == '.txt':
                f.write(str(data))
            elif ext == '.pkl':
                pickle.dump(data, f)
            else:
                raise ValueError("Unsupported file type")

    @staticmethod
    def unzip(zip_path, extract_to):
        if not zipfile.is_zipfile(zip_path):
            raise ValueError("Not a valid zip file.")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)

    @staticmethod
    def zip(output_zip, *paths):
        with zipfile.ZipFile(output_zip, 'w') as zipf:
            for path in paths:
                if os.path.isdir(path):
                    for root, _, files in os.walk(path):
                        for file in files:
                            zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), path))
                else:
                    zipf.write(path)

    @staticmethod
    def create(file_path):
        with open(file_path, 'w') as f:
            pass

    @staticmethod
    def rm(path):
        if os.path.exists(path):
            os.remove(path)
        else:
            raise FileNotFoundError(f"File '{path}' not found.")

    @staticmethod
    def encrypt(file_path, key):
        with open(file_path, 'rb') as f:
            data = f.read()
        encrypted_data = bytes([b ^ ord(key[i % len(key)]) for i, b in enumerate(data)])
        with open(file_path + '.enc', 'wb') as f:
            f.write(encrypted_data)

    @staticmethod
    def decrypt(file_path, key):
        if not file_path.endswith('.enc'):
            raise ValueError("File must be '.enc' encrypted file.")
        with open(file_path, 'rb') as f:
            data = f.read()
        decrypted_data = bytes([b ^ ord(key[i % len(key)]) for i, b in enumerate(data)])
        with open(file_path[:-4], 'wb') as f:
            f.write(decrypted_data)
