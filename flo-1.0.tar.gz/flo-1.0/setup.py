from setuptools import setup, find_packages

setup(
    name="flo",
    version="1.0",
    packages=find_packages(),
    description="A simple file operation library for beginners",
    author="Raffa552",
    install_requires=[],
)

